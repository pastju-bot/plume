#!/bin/bash
python3 update.py --update
python3 ms_rewards_farmer.py
